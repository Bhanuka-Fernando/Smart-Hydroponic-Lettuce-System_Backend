from fastapi import APIRouter, UploadFile, File, Form, Depends
from sqlalchemy.orm import Session
from datetime import datetime, timedelta    
from sqlalchemy import func
from app.core.db_models import SensorReading, PredictionLog
import os
import base64
from pydantic import ValidationError


UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

from app.schemas import PanelTodayResponse

from app.schemas import (
    InferRequest,
    InferResponse,
    ForecastRequest,
    ForecastResponse,
)
from app.services.vision import get_proj_area_and_diam
from app.services.leaf_area import leaf_area_from_proj
from app.services.weight import predict_weight_g
from app.services.growth import predict_tomorrow, forecast_n_days
from fastapi import HTTPException

from fastapi import UploadFile, File
from fastapi.responses import Response
from app.services.vision import make_mask_applied_png, make_mask_overlay_png


#IOT Imports
from app.core.db_deps import get_db
from app.core.db_models import SensorReading, PlantScan, PredictionLog
from app.schemas import SensorPacket, LatestDashboardResponse
from app.services.iot_agg import get_3day_means

router = APIRouter(prefix="/infer", tags=["inference"])


@router.post("/today", response_model=InferResponse)
async def infer_today(
    payload_json: str = Form(...),
    image: UploadFile = File(...),
    depth: UploadFile = File(...),
    db: Session = Depends(get_db),
):

    try:
        payload = InferRequest.model_validate_json(payload_json)
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=e.errors())

    rgb_bytes = await image.read()
    depth_bytes = await depth.read()

    A_proj_cm2, D_proj_cm, Z_m = get_proj_area_and_diam(rgb_bytes, depth_bytes)

    A_des_cm2 = leaf_area_from_proj(A_proj_cm2, D_proj_cm)
    W_today_g = predict_weight_g(A_des_cm2, D_proj_cm)


    # ✅ create overlay mask png (bytes) and encode
    mask_png = make_mask_overlay_png(rgb_bytes, alpha=0.45)
    mask_b64 = base64.b64encode(mask_png).decode("utf-8")

    # 1) save instant sensors (if provided)
    if payload.sensors is not None:
        db.add(SensorReading(
            zone_id=payload.zone_id,
            ts=datetime.utcnow(),
            airT=payload.sensors.airT,
            RH=payload.sensors.RH,
            EC=payload.sensors.EC,
            pH=payload.sensors.pH,
        ))
        db.commit()

    # 2) compute 3-day means (model inputs)
    means = get_3day_means(db, payload.zone_id, datetime.utcnow()) or {}

    # 3) resolve A_prev from DB (unless client provided)
    A_prev = payload.A_prev_cm2
    if A_prev is None:
        prev = (
            db.query(PredictionLog)
            .filter(PredictionLog.plant_id == payload.plant_id)
            .order_by(PredictionLog.ts.desc())
            .first()
        )
        A_prev = float(prev.A_proj_cm2) if prev and prev.A_proj_cm2 is not None else float(A_proj_cm2)

    # 4) predict using MEANS
    A_tmr, D_tmr = predict_tomorrow(
        dap=payload.dap,
        A_t_cm2=A_proj_cm2,
        D_t_cm=D_proj_cm,
        A_prev_cm2=A_prev,
        sensors=means,  # ✅ dict with mean keys
    )

    # 5) store prediction log so next call has history
    db.add(PredictionLog(
        plant_id=payload.plant_id,
        zone_id=payload.zone_id,
        ts=datetime.utcnow(),
        A_proj_cm2=float(A_proj_cm2),
        D_proj_cm=float(D_proj_cm),
        A_leaf_est_cm2=float(A_des_cm2),
        weight_est_g=float(W_today_g),
        A_next_cm2=float(A_tmr),
        D_next_cm=float(D_tmr),
    ))
    db.commit()
    

    A_leaf_tmr = leaf_area_from_proj(A_tmr, D_tmr)
    W_tmr_g = predict_weight_g(A_leaf_tmr, D_tmr)

    return InferResponse(
        A_proj_cm2=A_proj_cm2,
        D_proj_cm=D_proj_cm,
        A_des_cm2=A_des_cm2,
        W_today_g=W_today_g,
        A_proj_tmr_cm2=A_tmr,
        D_proj_tmr_cm=D_tmr,
        W_tmr_g=W_tmr_g,
        mask_overlay_b64=mask_b64,
    )

@router.post("/forecast", response_model=ForecastResponse)
async def infer_forecast(payload: ForecastRequest, db: Session = Depends(get_db)):
    # 1) get raw projected forecasts
    points_raw = forecast_n_days(
        dap_start=payload.dap,
        A_prev_cm2=payload.A_prev_cm2,
        A_t_cm2=payload.A_t_cm2,
        D_t_cm=payload.D_t_cm,
        sensors=payload.sensors,
        n_days=payload.n_days,
    )

    # 2) enrich each point with leaf area + weight
    points_out = []
    for p in points_raw:
        A_proj = float(p["A_pred_cm2"])
        D_cm = float(p["D_pred_cm"])

        A_leaf = float(leaf_area_from_proj(A_proj, D_cm))
        W_g = float(predict_weight_g(A_leaf, D_cm))

        points_out.append(
            {
                "step": int(p["step"]),
                "DAP_pred": int(p["DAP_pred"]),
                "A_pred_cm2": A_proj,
                "D_pred_cm": D_cm,
                "A_leaf_pred_cm2": A_leaf,
                "W_pred_g": W_g,
            }
        )

    return ForecastResponse(points=points_out)


@router.post("/panel/today", response_model=PanelTodayResponse)
async def panel_today(
    payload_json: str = Form(...),
    image: UploadFile = File(...),
    depth: UploadFile = File(...),
):
    payload = InferRequest.model_validate_json(payload_json)

    rgb_bytes = await image.read()
    depth_bytes = await depth.read()

    # vision gives projected A,D (internal)
    A_proj_cm2, D_cm, _ = get_proj_area_and_diam(rgb_bytes, depth_bytes)

    # convert to leaf area for output
    A_leaf_cm2 = leaf_area_from_proj(A_proj_cm2, D_cm)
    W_today_g = predict_weight_g(A_leaf_cm2, D_cm)

    A_prev = payload.A_prev_cm2 if payload.A_prev_cm2 is not None else A_proj_cm2
    A_proj_tmr, D_tmr = predict_tomorrow(payload.dap, A_proj_cm2, D_cm, A_prev, payload.sensors)

    A_leaf_tmr_cm2 = leaf_area_from_proj(A_proj_tmr, D_tmr)
    W_tmr_g = predict_weight_g(A_leaf_tmr_cm2, D_tmr)

    return PanelTodayResponse(
        Leaf_Area_today_cm2=A_leaf_cm2,
        Diameter_today_cm=D_cm,
        Weight_today_g=W_today_g,
        Leaf_Area_tomorrow_cm2=A_leaf_tmr_cm2,
        Diameter_tomorrow_cm=D_tmr,
        Weight_tomorrow_g=W_tmr_g,
    )


@router.post("/mask/applied")
async def download_mask_applied(image: UploadFile = File(...)):
    rgb_bytes = await image.read()
    png_bytes = make_mask_applied_png(rgb_bytes)
    return Response(
        content=png_bytes,
        media_type="image/png",
        headers={"Content-Disposition": 'attachment; filename="plant_mask_applied.png"'},
    )

@router.post("/mask/overlay")
async def download_mask_overlay(image: UploadFile = File(...)):
    rgb_bytes = await image.read()
    png_bytes = make_mask_overlay_png(rgb_bytes, alpha=0.5)
    return Response(
        content=png_bytes,
        media_type="image/png",
        headers={"Content-Disposition": 'attachment; filename="plant_mask_overlay.png"'},
    )


## IOT ROUTES

@router.post("/iot/ingest")
def iot_ingest(packet: SensorPacket, db: Session = Depends(get_db)):
    row = SensorReading(**packet.model_dump())
    db.add(row)
    db.commit()
    return {"ok": True}


@router.post("/scans/ingest")
async def scans_ingest(
    device_id: str = Form(...),
    plant_id: str = Form(...),
    zone_id: str = Form(...),
    ts: str = Form(...),
    rgb_image: UploadFile = File(...),
    depth_image: UploadFile | None = File(None),
    db: Session = Depends(get_db),
):
    ts_dt = datetime.fromisoformat(ts)

    # 1) READ BYTES (vision needs bytes, not file paths)
    rgb_bytes = await rgb_image.read()
    depth_bytes = await depth_image.read() if depth_image else None

    if depth_bytes is None:
        return {"ok": False, "error": "depth_image is required for this vision pipeline"}

    # 2) (Optional) SAVE FILES for demo/history
    rgb_path = os.path.join(
        UPLOAD_DIR, f"{plant_id}_{int(ts_dt.timestamp())}_{rgb_image.filename}"
    )
    with open(rgb_path, "wb") as f:
        f.write(rgb_bytes)

    depth_path = os.path.join(
        UPLOAD_DIR, f"{plant_id}_{int(ts_dt.timestamp())}_{depth_image.filename}"
    )
    with open(depth_path, "wb") as f:
        f.write(depth_bytes)

    # 3) LOG SCAN in DB
    db.add(
        PlantScan(
            device_id=device_id,
            plant_id=plant_id,
            zone_id=zone_id,
            ts=ts_dt,
            rgb_path=rgb_path,
            depth_path=depth_path,
        )
    )
    db.commit()

    # 4) VISION EXTRACTOR (returns tuple: A_cm2, D_cm, Z_m)
    A_proj_cm2, D_proj_cm, Z_m = get_proj_area_and_diam(rgb_bytes, depth_bytes)

    if A_proj_cm2 <= 0 or D_proj_cm <= 0:
        return {
            "ok": False,
            "error": "vision returned zero area/diameter (bad mask or invalid depth)",
            "A_proj_cm2": float(A_proj_cm2),
            "D_proj_cm": float(D_proj_cm),
            "Z_m": float(Z_m),
        }

    # 5) LEAF AREA + WEIGHT
    A_leaf_est_cm2 = float(leaf_area_from_proj(A_proj_cm2, D_proj_cm))
    W_g = float(predict_weight_g(A_leaf_est_cm2, D_proj_cm))

    # 6) SENSOR 3-DAY MEANS (from DB)
    means = get_3day_means(db, zone_id, ts_dt)

    # 7) GROWTH PREDICTION (optional)
    A_next = None
    D_next = None
    if means:
        # For now: assume previous area = today (no history yet)
        # If your predict_tomorrow expects a Pydantic Sensors model, this might need adjustment.
        sensors_obj = type("SensorsObj", (), means)()
        A_next, D_next = predict_tomorrow(
            dap=25,  # TODO: compute from planted date
            A_t_cm2=A_proj_cm2,
            D_t_cm=D_proj_cm,
            A_prev_cm2=A_proj_cm2,
            sensors=sensors_obj,
        )
        A_next = float(A_next)
        D_next = float(D_next)

    # 8) STORE PREDICTION LOG
    db.add(
        PredictionLog(
            plant_id=plant_id,
            zone_id=zone_id,
            ts=ts_dt,
            A_proj_cm2=float(A_proj_cm2),
            D_proj_cm=float(D_proj_cm),
            A_leaf_est_cm2=float(A_leaf_est_cm2),
            weight_est_g=float(W_g),
            A_next_cm2=A_next,
            D_next_cm=D_next,
        )
    )
    db.commit()

    return {
        "ok": True,
        "plant_id": plant_id,
        "zone_id": zone_id,
        "ts": ts_dt.isoformat(),
        "A_proj_cm2": float(A_proj_cm2),
        "D_proj_cm": float(D_proj_cm),
        "Z_m": float(Z_m),
        "A_leaf_est_cm2": float(A_leaf_est_cm2),
        "weight_est_g": float(W_g),
        "A_next_cm2": A_next,
        "D_next_cm": D_next,
        "sensor_means_3d": means,
        "saved": {"rgb_path": rgb_path, "depth_path": depth_path},
    }



from sqlalchemy import desc

@router.get("/dashboard/latest", response_model=LatestDashboardResponse)
def dashboard_latest(zone_id: str, plant_id: str, db: Session = Depends(get_db)):
    latest_sensor = db.query(SensorReading).filter(
        SensorReading.zone_id == zone_id
    ).order_by(desc(SensorReading.ts)).first()

    latest_pred = db.query(PredictionLog).filter(
        PredictionLog.zone_id == zone_id,
        PredictionLog.plant_id == plant_id
    ).order_by(desc(PredictionLog.ts)).first()

    now = latest_pred.ts if latest_pred else (latest_sensor.ts if latest_sensor else datetime.utcnow())
    means = get_3day_means(db, zone_id, now) or {}

    return LatestDashboardResponse(
        zone_id=zone_id,
        plant_id=plant_id,
        ts=now,
        airT=getattr(latest_sensor, "airT", None) if latest_sensor else None,
        RH=getattr(latest_sensor, "RH", None) if latest_sensor else None,
        EC=getattr(latest_sensor, "EC", None) if latest_sensor else None,
        pH=getattr(latest_sensor, "pH", None) if latest_sensor else None,
        **means,
        A_proj_cm2=getattr(latest_pred, "A_proj_cm2", None) if latest_pred else None,
        D_proj_cm=getattr(latest_pred, "D_proj_cm", None) if latest_pred else None,
        A_leaf_est_cm2=getattr(latest_pred, "A_leaf_est_cm2", None) if latest_pred else None,
        weight_est_g=getattr(latest_pred, "weight_est_g", None) if latest_pred else None,
        A_next_cm2=getattr(latest_pred, "A_next_cm2", None) if latest_pred else None,
        D_next_cm=getattr(latest_pred, "D_next_cm", None) if latest_pred else None,
    )

from fastapi import HTTPException

@router.post("/weight/estimate")
async def weight_estimate_mobile(
    image: UploadFile = File(...),
    depth: UploadFile = File(...),
    plant_id: str = Form(None),
    captured_at: str = Form(None),
):
    rgb_bytes = await image.read()
    depth_bytes = await depth.read()

    try:
        A_proj_cm2, D_proj_cm, Z_m = get_proj_area_and_diam(rgb_bytes, depth_bytes)
        A_leaf_cm2 = leaf_area_from_proj(A_proj_cm2, D_proj_cm)
        W_today_g = predict_weight_g(A_leaf_cm2, D_proj_cm)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

    return {
        "plant_id": plant_id,
        "captured_at": captured_at,
        "biomass_g": float(W_today_g),
        "leaf_area_cm2": float(A_leaf_cm2),
        "leaf_diameter_cm": float(D_proj_cm),
        "z_m": float(Z_m),
    }


def save_instant_sensor(db, zone_id: str, sensors):
    if sensors is None:
        return
    row = SensorReading(
        zone_id=zone_id,
        airT=sensors.airT,
        RH=sensors.RH,
        EC=sensors.EC,
        pH=sensors.pH,
        ts=datetime.utcnow(),
    )
    db.add(row)
    db.commit()

def get_3d_means(db, zone_id: str, fallback_sensors):
    since = datetime.utcnow() - timedelta(days=3)

    avg_row = db.query(
        func.avg(SensorReading.airT),
        func.avg(SensorReading.RH),
        func.avg(SensorReading.EC),
        func.avg(SensorReading.pH),
    ).filter(
        SensorReading.zone_id == zone_id,
        SensorReading.ts >= since
    ).first()

    def pick(avg_val, fallback_val):
        return float(avg_val) if avg_val is not None else (float(fallback_val) if fallback_val is not None else 0.0)

    airT = pick(avg_row[0], getattr(fallback_sensors, "airT", None) if fallback_sensors else None)
    RH   = pick(avg_row[1], getattr(fallback_sensors, "RH", None) if fallback_sensors else None)
    EC   = pick(avg_row[2], getattr(fallback_sensors, "EC", None) if fallback_sensors else None)
    pH   = pick(avg_row[3], getattr(fallback_sensors, "pH", None) if fallback_sensors else None)

    # IMPORTANT: return MEAN feature names (what the model expects)
    return {
        "airT_mean_3d_C": airT,
        "RH_mean_3d_pct": RH,
        "EC_mean_3d_mScm": EC,
        "pH_mean_3d": pH,
    }

def get_A_prev_from_logs(db, plant_id: str):
    prev = db.query(PredictionLog).filter(PredictionLog.plant_id == plant_id).order_by(PredictionLog.ts.desc()).first()
    return float(prev.A_proj_cm2) if prev and prev.A_proj_cm2 is not None else None


@router.post("/growth/predict", response_model=ForecastResponse)
def growth_predict(req: ForecastRequest, db: Session = Depends(get_db)):

    # 1) Save instant sensors (so we can compute means next time)
    if req.sensors is not None:
        # req.sensors can be dict or Sensors — normalize quickly
        s = req.sensors if hasattr(req.sensors, "airT") else type("S", (), req.sensors)
        save_instant_sensor(db, req.zone_id, s)
    else:
        s = None

    # 2) Compute rolling means (what the model expects)
    means = get_3d_means(db, req.zone_id, s)

    # 3) Resolve A_prev
    A_prev = req.A_prev_cm2
    if A_prev is None:
        A_prev = get_A_prev_from_logs(db, req.plant_id)
    if A_prev is None:
        # first ever run → make deltaA=0 and RGR=0
        A_prev = float(req.A_t_cm2)

    # 4) Predict next days
    raw_points = forecast_n_days(
        dap_start=req.dap,
        A_prev_cm2=A_prev,
        A_t_cm2=req.A_t_cm2,
        D_t_cm=req.D_t_cm,
        sensors=means,        # ✅ MEANS keys
        n_days=req.n_days,
    )

    # 5) Enrich with leaf area + weight (your schema expects these)
    points = []
    for p in raw_points:
        A = float(p["A_pred_cm2"])
        D = float(p["D_pred_cm"])
        points.append({
            "step": int(p["step"]),
            "DAP_pred": int(p["DAP_pred"]),
            "A_pred_cm2": A,
            "D_pred_cm": D,
            "A_leaf_pred_cm2": A,                 # simplest consistent assumption
            "W_pred_g": float(predict_weight_g(A, D)),
        })

    return {"points": points}
